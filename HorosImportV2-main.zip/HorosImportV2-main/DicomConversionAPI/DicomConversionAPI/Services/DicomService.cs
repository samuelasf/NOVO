﻿using FellowOakDicom;
using FellowOakDicom.Network;
using FellowOakDicom.Network.Client;
using SixLabors.ImageSharp;
using System.Text;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Formats.Jpeg;
using DicomConversionAPI.Extensions;
using System.Diagnostics;
using DicomRequest = DicomConversionAPI.Models.DicomRequest;
using DicomConversionAPI.Models;
using System.Globalization;
using DicomConversionAPI.Helpers;
using System.Linq;
using FellowOakDicom.StructuredReport;

namespace DicomConversionAPI.Services
{
    public class DicomService : IDicomService
    {

        private readonly ILogger<DicomService> _logger;
        private readonly IConfiguration _configuration;

        private string remoteDicomAE;
        private string remoteDicomIP;
        private string remoteDicomPort;
        private string mwlFolderPath;


        public DicomService(ILogger<DicomService> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            remoteDicomAE = _configuration.GetSection("Settings").GetSection("RemoteDicomAE").Value;
            remoteDicomPort = _configuration.GetSection("Settings").GetSection("RemoteDicomPort").Value;
            remoteDicomIP = _configuration.GetSection("Settings").GetSection("RemoteDicomIP").Value;
            mwlFolderPath = _configuration.GetSection("Settings").GetSection("MWLFolderPath").Value;

        }


        private DicomUID GenerateUid()
        {
            StringBuilder uid = new StringBuilder();
            System.Threading.Thread.Sleep(1000);
            uid.Append("1.8.1982.10121984.2.0.7").Append('.').Append(DateTime.UtcNow.Ticks);
            return new DicomUID(uid.ToString(), "SOP Instance UID", DicomUidType.SOPInstance);
        }

        public  DicomUID GenerateUid2(string AppID, string OrderID)
        {
            string uid = GenerateNewUid("1.2.826.0.1.3680043.10.1054", AppID, OrderID);
            //return new DicomUID("1.2.826.0.1.3680043.10.1054."+  DicomHelper.FormatGuidAsString(Guid.NewGuid()) , "Instance UID", DicomUidType.SOPInstance) ;
            return new DicomUID( uid, "Instance UID", DicomUidType.SOPInstance);


        }

        private string GenerateNewUid(string orgroot, string appID, string OrderID)
        {
            //Gets date/time
            Thread.Sleep(500);
            var now = DateTime.Now;

            //Gets numeric date info without year...exact military time
            // string zeroDate = appID + now.Year.ToString() + now.Month.ToString() + now.Day.ToString() + "." + now.Hour.ToString() + now.Minute.ToString() + now.Second.ToString() + now.Millisecond.ToString();
            string zeroDate = appID + "."+ OrderID + "." + ( Convert.ToInt64(now.Year.ToString() + now.Month.ToString() + now.Day.ToString()) + Convert.ToInt64(now.Hour.ToString() + now.Minute.ToString() + now.Second.ToString() + now.Millisecond.ToString()));

            //Globally Unique Identifier
            string guid = new string(Guid.NewGuid().ToString().Where(char.IsDigit).ToArray());

            //Combines the strings
            string sopUid = $"{orgroot}.{zeroDate}.{guid}";

            //check the length of the string to see if it's over 64 characters long, if it is, then make a substring of it that is 64 chars long starting at char index 0
            //otherwise, use the original string
            sopUid = String.Join(".",sopUid.Split(".").Select(x => (x== "0")?x : x.TrimStart(new Char[] { '0' })).ToList());
            sopUid = sopUid.Length > 64 ? sopUid.Substring(0, 64) : sopUid;
            return sopUid;
        }

        public async Task<string> GetFileExtension(string base64String)
        {
            string datatype = base64String.Split(';')[0].Split('/')[1];

            return datatype;
        }

        public async Task<bool> WriteMWLV2(DicomRequestV2 dicomRequest )
        {
            string mwl_file = string.Empty;
            mwl_file = mwlFolderPath + Path.DirectorySeparatorChar.ToString() + dicomRequest.institutionName+"."+ dicomRequest.accession + ".txt";

            try
            {
                if (System.IO.File.Exists(mwl_file)) System.IO.File.Delete(mwl_file);
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("NOME=" + dicomRequest.patientName);
                sb.AppendLine("PRONTUÁRIO=" + dicomRequest.patientId);
                sb.AppendLine("GUIA=" + dicomRequest.accession);
                sb.AppendLine("SEXO="); //+ dicomRequest.sex);
                sb.AppendLine("NASCIMENTO=" + DateTime.Parse(dicomRequest.dob, new CultureInfo("en-CA")).ToString("yyyyMMdd"));
                sb.AppendLine("INSTITUIÇÃO=" + dicomRequest.institutionName);
                sb.AppendLine("MODALIDADE=" + dicomRequest.modality);
                sb.AppendLine("SOLICITANTE=");//+ dicomRequest.referingPhysician);
                sb.AppendLine("EXECUTANTE=" );//+ dicomRequest.performer);
                sb.AppendLine("DESCRIÇÃO DO EXAME="); //+ dicomRequest.examDescription);
                sb.AppendLine("HISTORIA CLINICA=");// + dicomRequest.clinicalHistory);
                sb.AppendLine("COMENTARIOS="  + dicomRequest.comments);
                sb.AppendLine("DATA=" + DateTime.Now.ToString("yyyyMMdd"));
                sb.AppendLine("HORA=" + DateTime.Now.ToString("HHmmss"));
                sb.AppendLine("DATA DE CRIAÇÃO="+ DateTime.Now.ToString("yyyyMMdd"));

                File.WriteAllText(mwl_file, sb.ToString());
                return true;

            }
            catch
            {

                System.IO.File.Delete(mwl_file);
                Log(String.Format("Failed Writing MWL:{0}", mwl_file));
                return false;
            }
        }

     
        public async Task<string> PdfToDicomV2(string filePath, DicomRequestV2 dicomRequest)
        {
            if (!File.Exists(filePath)) return "";
            string dicom_file = Path.ChangeExtension(filePath, ".dcm");

            try
            {
                var generator = new DicomUIDGenerator();
                //var studyUID = GenerateUid();
                DateTime dob = DateTime.Parse(dicomRequest.dob, new CultureInfo("en-CA"));
                string todayDate = DateTime.Now.ToString("yyyyMMdd");
                string todaytime = DateTime.Now.ToString("HHmmss");
                //string studyDate = dicomRequest.studyDateTime.HasValue ? dicomRequest.studyDateTime.Value.ToString("yyyyMMdd") : "";
                byte[] pdf = System.IO.File.ReadAllBytes(filePath);
                if (System.IO.File.Exists(dicom_file)) System.IO.File.Delete(dicom_file);


                //  Dicom Conversion

                Process process = new Process();
                // Configure the process using the StartInfo properties.
                process.StartInfo.FileName = "pdf2dcm";
                process.StartInfo.Arguments = filePath + " " + dicom_file;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.Start();
                process.WaitForExit();// Waits here for the process to exit.



                //string studyDate = dicomRequest.studyDateTime.HasValue ? dicomRequest.studyDateTime.Value.ToString("yyyyMMdd") : "";

                if (!File.Exists(dicom_file)) throw new Exception("Couldnt convert pdf2dcm");

                DicomFile dicomFile = DicomFile.Open(dicom_file, FileReadOption.ReadAll);

                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientID, dicomRequest.patientId);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientName, dicomRequest.patientName);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.InstitutionName, dicomRequest.institutionName);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientBirthDate, dob.ToString("yyyyMMdd"));
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.AcquisitionDate, todayDate);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.AcquisitionTime, todaytime);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.StudyDescription, dicomRequest.modality);
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientSex, dicomRequest.sex == "Male" ? "M" : "F");
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.StudyDate, studyDate);
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.StudyDate, studyDate);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.SeriesDescription, "imagem");
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PerformingPhysicianName, dicomRequest.performer);
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.ReferringPhysicianName, dicomRequest.referingPhysician);
                //dicomFile.Dataset.AddOrUpdate(DicomTag.StudyInstanceUID, GenerateUid2("2"));
                //dicomFile.Dataset.AddOrUpdate(DicomTag.SeriesInstanceUID, GenerateUid2("2"));
                //dicomFile.Dataset.AddOrUpdate(DicomTag.SOPInstanceUID, GenerateUid2("2"));
                dicomFile.Dataset.AddOrUpdate(DicomTag.Modality, "OT");
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.AccessionNumber, dicomRequest.accession);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.CreationDate, todayDate);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.CreationTime, todaytime);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientComments, dicomRequest.comments);


                dicomFile.Save(dicom_file);

                _logger.LogInformation(String.Format("Dicom Converted :{0}", dicom_file));
                return dicom_file;

            }
            catch
            {
                System.IO.File.Delete(dicom_file);
                Log(String.Format("Failed Dicom Conversion :{0}", dicom_file));
                return "";
            }
        }

        public async Task<string> ImageToDicomV2(string filePath, DicomRequestV2 dicomRequest, string filePathToDownload = "")
        {
            string dicom_file = Path.ChangeExtension(filePath, ".dcm");
            DateTime dob = DateTime.Parse(dicomRequest.dob, new CultureInfo("en-CA"));
            try
            {
                if (!File.Exists(filePath)) return "";


                /// Connecting to PACS

                Image image;
                try
                {
                    Image.Load(filePath).SaveAsJpeg(filePath);

                }
                catch
                {
                    throw new Exception("Cant read file");
                }


                if (System.IO.File.Exists(dicom_file)) System.IO.File.Delete(dicom_file);

                //  Dicom Conversion

                Process process = new Process();
                // Configure the process using the StartInfo properties.
                process.StartInfo.FileName = "img2dcm";
                process.StartInfo.Arguments = filePath + " " + dicom_file;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.Start();
                process.WaitForExit();// Waits here for the process to exit.

                //// Dicom Data Set Manipulation

                //var generator = new DicomUIDGenerator();
                //var studyUID = GenerateUid();

                string todayDate = DateTime.Now.ToString("yyyyMMdd");
                string todaytime = DateTime.Now.ToString("HHmmss");
                

                //string studyDate = dicomRequest.studyDateTime.HasValue ? dicomRequest.studyDateTime.Value.ToString("yyyyMMdd") : "";

                if (!File.Exists(dicom_file)) throw new Exception("Couldnt convert img2dcm");

                DicomFile dicomFile = DicomFile.Open(dicom_file, FileReadOption.ReadAll);
                

                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientID, dicomRequest.patientId);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientName, dicomRequest.patientName);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.InstitutionName, dicomRequest.institutionName);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientBirthDate, dob.ToString("yyyyMMdd"));
                
                if (filePathToDownload.Length > 0 && dicomRequest.generate == "ANY")
                {
                    dicomFile.Dataset.AddOrUpdate<string>(DicomTag.StudyDescription, dicomRequest.modality);
                    dicomFile.Dataset.AddOrUpdate<string>(DicomTag.AdditionalPatientHistory, filePathToDownload);
                }
                else 
                {
                    dicomFile.Dataset.AddOrUpdate<string>(DicomTag.StudyDescription, dicomRequest.modality);
                    dicomFile.Dataset.AddOrUpdate<string>(DicomTag.AccessionNumber, dicomRequest.accession);
                }
                
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientSex, dicomRequest.sex == "Male" ? "M" : "F");
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.StudyDate, studyDate);
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.StudyDate, studyDate);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.SeriesDescription, "imagem");
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PerformingPhysicianName, dicomRequest.performer);
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.ReferringPhysicianName, dicomRequest.referingPhysician);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.AccessionNumber, dicomRequest.accession);
                //dicomFile.Dataset.AddOrUpdate(DicomTag.StudyInstanceUID, GenerateUid2("1"));
                //dicomFile.Dataset.AddOrUpdate(DicomTag.SeriesInstanceUID, GenerateUid2("1"));
                //dicomFile.Dataset.AddOrUpdate(DicomTag.SOPInstanceUID, GenerateUid2("1"));
                dicomFile.Dataset.AddOrUpdate(DicomTag.Modality, "OT");
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.CreationDate, todayDate);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.AcquisitionDate, todayDate);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.AcquisitionTime, todaytime );
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.CreationTime, todaytime);
                dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientComments, dicomRequest.comments);



                dicomFile.Save(dicom_file);


                _logger.LogInformation(String.Format("Dicom Converted :{0}", dicom_file));
                return dicom_file;

            }
            catch
            {

                System.IO.File.Delete(dicom_file);
                Log(String.Format("Failed Dicom Conversion :{0}", dicom_file));
                return "";
            }
        }


        public async Task<string> GenerateDicomSR(string folderPath, DicomRequestV2 dicomRequest, string filePathToDownload = "")
        {
            
            string dicom_file = folderPath+ Path.DirectorySeparatorChar+Path.ChangeExtension(Guid.NewGuid().ToString(), ".dcm");
            DateTime dob = DateTime.Parse(dicomRequest.dob, new CultureInfo("en-CA"));
            try
            {
                
                if (System.IO.File.Exists(dicom_file)) System.IO.File.Delete(dicom_file);                


                string todayDate = DateTime.Now.ToString("yyyyMMdd");
                string todaytime = DateTime.Now.ToString("HHmmss");


                //string studyDate = dicomRequest.studyDateTime.HasValue ? dicomRequest.studyDateTime.Value.ToString("yyyyMMdd") : "";


                var dataset = new DicomDataset();



                dataset.AddOrUpdate<string>(DicomTag.PatientID, dicomRequest.patientId);
                dataset.AddOrUpdate<string>(DicomTag.PatientName, dicomRequest.patientName);
                dataset.AddOrUpdate<string>(DicomTag.InstitutionName, dicomRequest.institutionName);
                dataset.AddOrUpdate<string>(DicomTag.PatientBirthDate, dob.ToString("yyyyMMdd"));
                dataset.AddOrUpdate(DicomTag.StudyInstanceUID, GenerateUid2("1" , "1"));
                dataset.AddOrUpdate(DicomTag.SeriesInstanceUID, GenerateUid2("1", "2"));
                dataset.AddOrUpdate(DicomTag.SOPInstanceUID, GenerateUid2("1","3"));    
                dataset.AddOrUpdate(DicomTag.MediaStorageSOPInstanceUID, GenerateUid2("1", "3"));
                dataset.AddOrUpdate(DicomTag.SOPClassUID, DicomUID.BasicTextSRStorage);
                

                //if (filePathToDownload.Length > 0 && dicomRequest.generate == "ANY")
                //{
                //    dataset.AddOrUpdate<string>(DicomTag.StudyDescription, dicomRequest.modality);
                //    dataset.AddOrUpdate<string>(DicomTag.AccessionNumber, filePathToDownload);
                //}
                //else
                //{
                //    dataset.AddOrUpdate<string>(DicomTag.StudyDescription, dicomRequest.modality);
                //    dataset.AddOrUpdate<string>(DicomTag.AccessionNumber, dicomRequest.accession);
                //}
                dataset.AddOrUpdate<string>(DicomTag.StudyDescription, dicomRequest.modality);
                dataset.AddOrUpdate<string>(DicomTag.AccessionNumber, dicomRequest.accession);

                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PatientSex, dicomRequest.sex == "Male" ? "M" : "F");
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.StudyDate, studyDate);
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.StudyDate, studyDate);
                dataset.AddOrUpdate<string>(DicomTag.SeriesDescription, "Laudo");
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.PerformingPhysicianName, dicomRequest.performer);
                //dicomFile.Dataset.AddOrUpdate<string>(DicomTag.ReferringPhysicianName, dicomRequest.referingPhysician);
                dataset.AddOrUpdate<string>(DicomTag.AccessionNumber, dicomRequest.accession);
                dataset.AddOrUpdate(DicomTag.TransferSyntaxUID, DicomTransferSyntax.ExplicitVRLittleEndian);
                //dicomFile.Dataset.AddOrUpdate(DicomTag.StudyInstanceUID, GenerateUid2("1"));
                //dicomFile.Dataset.AddOrUpdate(DicomTag.SeriesInstanceUID, GenerateUid2("1"));
                //dicomFile.Dataset.AddOrUpdate(DicomTag.SOPInstanceUID, GenerateUid2("1"));
                
                dataset.AddOrUpdate(DicomTag.Modality, "SR");
                dataset.AddOrUpdate<string>(DicomTag.CreationDate, todayDate);
                dataset.AddOrUpdate<string>(DicomTag.AcquisitionDate, todayDate);
                dataset.AddOrUpdate<string>(DicomTag.AcquisitionTime, todaytime);
                dataset.AddOrUpdate<string>(DicomTag.CreationTime, todaytime);

                dataset.AddOrUpdate(DicomTag.VerificationFlag, "UNVERIFIED");
                dataset.AddOrUpdate(DicomTag.CompletionFlag, "1");

                

                var strReport = new DicomStructuredReport(dataset);
                

                var urlContentItem = new DicomContentItem(
                   new DicomCodeItem("111412", "DCM", "Url"),
                   DicomRelationship.Contains,DicomValueType.Text, filePathToDownload
                   );
                strReport.Add(urlContentItem);

                //var urlContentItem = new DicomContentItem(
                //   new DicomCodeItem(filePathToDownload, "companyName", "Finding"),
                //   DicomRelationship.Contains,
                //   new DicomCodeItem(filePathToDownload, "companyName", "Finding"));
                //strReport.Add(urlContentItem);

                DicomFile dicomFile = new DicomFile();
                dicomFile.Dataset.Add(dataset);
                dicomFile.FileMetaInfo.TransferSyntax = DicomTransferSyntax.ExplicitVRLittleEndian;
                dicomFile.Save(dicom_file);


                _logger.LogInformation(String.Format("Dicom Converted :{0}", dicom_file));
                return dicom_file;

            }
            catch
            {

                System.IO.File.Delete(dicom_file);
                Log(String.Format("Failed Dicom Conversion :{0}", dicom_file));
                return "";
            }
        }




        public async Task<bool> sendToPACS(string dicom_file)
        {
            try
            {
                var dicom_client = DicomClientFactory.Create(remoteDicomIP, int.Parse(remoteDicomPort), false, "DICOM-IMPORT", remoteDicomAE);
                await dicom_client.AddRequestAsync(new DicomCStoreRequest(dicom_file));
                await dicom_client.SendAsync();
                if (System.IO.File.Exists(dicom_file)) System.IO.File.Delete(dicom_file);

                return true;
            }
            catch
            {                
                Log(String.Format("Failed Dicom send :{0}", dicom_file));
                return false;
            }
        }



        public void Log(string message)
        {
            _logger.LogInformation($"{message}");
        }

    }
}

