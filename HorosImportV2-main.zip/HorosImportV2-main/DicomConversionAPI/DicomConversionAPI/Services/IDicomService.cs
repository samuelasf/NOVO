﻿using DicomConversionAPI.Models;

namespace DicomConversionAPI.Services
{
    public interface IDicomService
    {
        
        void Log(string message);
        
        Task<string> GetFileExtension(string base64String);

        
        Task<bool> WriteMWLV2(DicomRequestV2 dicomRequest);
        Task<bool> sendToPACS(string dicom_file);
        Task<string> ImageToDicomV2(string filePath, DicomRequestV2 dicomRequest, string filePathToDownload = "");

        Task<string> GenerateDicomSR(string folderPath, DicomRequestV2 dicomRequest, string filePathToDownload = "");
        
        Task<string> PdfToDicomV2(string filePath, DicomRequestV2 dicomRequest);
    }
}