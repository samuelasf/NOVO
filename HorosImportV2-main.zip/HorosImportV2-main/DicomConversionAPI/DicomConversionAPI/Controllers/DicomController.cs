using FellowOakDicom;
using FellowOakDicom.Network;
using FellowOakDicom.Network.Client;
using Microsoft.AspNetCore.Mvc;
using DicomConversionAPI.Services;
using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using DicomConversionAPI.Models;
using DicomRequest = DicomConversionAPI.Models.DicomRequest;
using DicomConversionAPI.Helpers;
using System.Web;

namespace DicomConversionAPI.Controllers
{
    [ApiController]

    [Route("api")]
    public class DicomController : ControllerBase
    {

        private readonly ILogger<DicomController> _logger;
        private readonly IConfiguration _configuration;
        private readonly Services.IDicomService _dicomService;
        private string internalCacheFolderPath;
        private string logosFolderPath;
        private string archiveCacheFolderPath;


        public DicomController(ILogger<DicomController> logger, IConfiguration configuration, Services.IDicomService dicomService)
        {
            _logger = logger;
            _configuration = configuration;
            _dicomService = dicomService;
            internalCacheFolderPath = _configuration.GetSection("Settings").GetSection("InternalCacheFolderPath").Value;
            logosFolderPath = _configuration.GetSection("Settings").GetSection("logosFolderPath").Value;
            archiveCacheFolderPath = _configuration.GetSection("Settings").GetSection("archiveCacheFolderPath").Value;



        }



        [Route("dicomconvert/imageOrPdf")]
        [HttpPost]
        public async Task<ActionResult> imageOrPDFToDicom(DicomRequestV2 dicomRequest)
        {
            string fileType = dicomRequest.filedata.Split(';')[0].Split('/')[1];  
            string base64File = dicomRequest.filedata.Split(';')[1].Replace("base64,","");
            if (fileType == string.Empty) return BadRequest();


            if (dicomRequest.generate == "ANY")
            {

                string filePathlogo_X = logosFolderPath + Path.DirectorySeparatorChar.ToString() + dicomRequest.institutionName + ".jpg";
                string filePathlogo = internalCacheFolderPath + Path.DirectorySeparatorChar.ToString() + Guid.NewGuid().ToString() + ".jpg";
                System.IO.File.Copy(filePathlogo_X, filePathlogo);

                if (!System.IO.File.Exists(filePathlogo)) return BadRequest("error_1");

                if (fileType == "x-zip-compressed") fileType = "zip";

                string filePathTarget = archiveCacheFolderPath + Path.DirectorySeparatorChar.ToString() + dicomRequest.patientId + "." + dicomRequest.institutionName + "." + dicomRequest.accession + "." + fileType;
                if (System.IO.File.Exists(filePathTarget)) System.IO.File.Delete(filePathTarget);
                System.IO.File.WriteAllBytes(filePathTarget, Convert.FromBase64String(base64File));
                if (!System.IO.File.Exists(filePathTarget)) return BadRequest("Could not write the file");


                string filePathZipDownload = @"http://arquivo.exames.center/" + HttpUtility.UrlEncode(dicomRequest.patientId + "." + dicomRequest.institutionName + "." + dicomRequest.accession + "." + fileType);


                string res = await _dicomService.ImageToDicomV2(filePathlogo, dicomRequest, filePathZipDownload);
                //string res = await _dicomService.GenerateDicomSR(internalCacheFolderPath, dicomRequest, filePathZipDownload);
                
                bool result = (res.Length > 0) ? true : false;
                result = result && await _dicomService.sendToPACS(res);
                //if (dicomRequest.generateMWL == true) result = result && await _dicomService.WriteMWLV2(dicomRequest);

                if (result)
                {
                    System.IO.File.Delete(res);
                    //System.IO.File.Delete(filePathTarget);
                }


                return Ok(new List<ResultModel> { new ResultModel { file = res, status = result ? "success" : "failure" } });

            }
            else if (dicomRequest.generate == "DICOM")
            {

                Guid imageId = Guid.NewGuid();

                string filePath = internalCacheFolderPath + Path.DirectorySeparatorChar.ToString() + imageId + "." + fileType;
                if (System.IO.File.Exists(filePath)) System.IO.File.Delete(filePath);
                System.IO.File.WriteAllBytes(filePath, Convert.FromBase64String(base64File));


                if (fileType == "png" || fileType == "jpeg" || fileType == "jpg")
                {

                    try
                    {
                        string res = await _dicomService.ImageToDicomV2(filePath, dicomRequest);
                        bool result = (res.Length > 0) ? true : false;
                        result = result && await _dicomService.sendToPACS(res);

                        if (result)
                        {
                            System.IO.File.Delete(res);
                            System.IO.File.Delete(filePath);
                        }


                        return Ok(new List<ResultModel> { new ResultModel { file = res, status = result ? "success" : "failure" } });

                    }
                    catch (Exception ex)
                    {
                        return Ok(new List<ResultModel> { new ResultModel { file = filePath, status = "failure" } });

                    }
                }
                else if (fileType == "pdf")
                {
                    try
                    {

                        string res = await _dicomService.PdfToDicomV2(filePath, dicomRequest);

                        bool result = (res.Length > 0) ? true : false;
                        result = result && await _dicomService.sendToPACS(res);
                        //if (dicomRequest.generateMWL == true) result = result && await _dicomService.WriteMWLV2(dicomRequest);

                        if (result)
                        {
                            System.IO.File.Delete(res);
                            System.IO.File.Delete(filePath);
                        }


                        return Ok(new List<ResultModel> { new ResultModel { file = res, status = result ? "success" : "failure" } });
                    }
                    catch (Exception ex)
                    {
                        return Ok(new List<ResultModel> { new ResultModel { file = filePath, status = "failure" } });
                    }
                }
                else if (fileType == "x-zip-compressed")
                {

                    List<ResultModelV2> results = new List<ResultModelV2>();
                    try
                    {

                        // if (!System.IO.Path.GetExtension(filePath).Equals("zip", StringComparison.InvariantCultureIgnoreCase)) return BadRequest("Not a zip file");

                        string dirPath = Path.GetDirectoryName(filePath) + Path.DirectorySeparatorChar + Path.GetFileNameWithoutExtension(filePath);


                        if (Directory.Exists(dirPath)) Directory.Delete(dirPath);
                        Directory.CreateDirectory(dirPath);
                        ZipFile.ExtractToDirectory(filePath, dirPath, true);

                        string[] dirs = Directory.GetDirectories(dirPath, "*", SearchOption.TopDirectoryOnly);

                        foreach (string _file in Directory.GetFiles(dirPath))
                        {
                            string newFile = DicomHelper.ReplaceWhitespace(_file, "_");
                            System.IO.File.Move(_file, newFile);
                            switch (System.IO.Path.GetExtension(newFile.ToLower()))
                            {
                                case ".jpg":
                                case ".jpeg":
                                case ".png":
                                    string resImage = await _dicomService.ImageToDicomV2(newFile, dicomRequest);
                                    bool resultImage = (resImage.Length > 0) ? true : false;
                                    results.Add(new ResultModelV2 { dicomfile = resImage, sourcefile = newFile, status = resultImage ? "success" : "failure" });
                                    break;


                                case ".pdf":
                                    string resPDF = await _dicomService.PdfToDicomV2(newFile, dicomRequest);
                                    bool resultPDF = (resPDF.Length > 0) ? true : false;
                                    results.Add(new ResultModelV2 { dicomfile = resPDF, sourcefile = newFile, status = resultPDF ? "success" : "failure" });
                                    break;
                            }
                        }
                        bool result = !results.Any(x => x.status == "failure");

                        foreach (var res in results)
                        {
                            if (!result) return BadRequest();
                            result = result && await _dicomService.sendToPACS(res.dicomfile);
                            if (result)
                            {
                                System.IO.File.Delete(res.dicomfile);
                                System.IO.File.Delete(res.sourcefile);
                            }
                        }


                        //if (dicomRequest.generateMWL == true) result = result && await _dicomService.WriteMWLV2(dicomRequest);


                        if (Directory.GetFiles(dirPath).Length == 0)
                        {
                            Directory.Delete(dirPath);
                        }

                        return Ok(results);

                    }
                    catch (Exception ex)
                    {
                        if (results.Count > 0) return Ok(results);

                        return Ok(new List<ResultModel> { new ResultModel { file = filePath, status = "failure" } });
                    }


                }

            }
            else if (dicomRequest.generate == "MWL") {

                var result = await _dicomService.WriteMWLV2(dicomRequest);
                return Ok(new List<ResultModel> { new ResultModel { file = "MWL", status = result ? "success" : "failure" } });


            }
            return BadRequest();
        }

       



        [Route("dicomconvert/mwl")]
        [HttpPost]
        public async Task<ActionResult> mwlsend(DicomRequestV2 requestModel)
        {
            try
            {
                bool resultMWL = await _dicomService.WriteMWLV2(requestModel);
                return Ok(true);
            }
            catch (Exception ex)
            {
                return Ok(false);
            }
            
        }



       


    }
}