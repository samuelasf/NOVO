﻿using System;
using System.IO;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Advanced;
using SixLabors.ImageSharp.Formats;
using SixLabors.ImageSharp.PixelFormats;

namespace DicomConversionAPI.Extensions
{
    
    public static class ImageSharpExtensions
    {
        public static Byte[] ToArray(this Image image, IImageEncoder imageEncoder) 
        {
           
            using (var memoryStream = new MemoryStream())
            {
                //var imageEncoder = image.GetConfiguration().ImageFormatsManager.FindEncoder(imageFormat);
                image.Save(memoryStream, imageEncoder);
                return memoryStream.ToArray();
            }
        }
    }
}
