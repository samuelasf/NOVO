﻿namespace DicomConversionAPI.Middleware
{
    public class IPWhitelistOptions
    {
        public List<string> Whitelist { get; set; }
    }
}
