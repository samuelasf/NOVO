﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace DicomConversionAPI.Models
{
    public class ResultModel
    {
        public string file { get; set; }
        public string status { get; set; }

    }

    public class ResultModelV2
    {
        public string sourcefile { get; set; }
        public string dicomfile { get; set; }
        public string status { get; set; }

    }





}
