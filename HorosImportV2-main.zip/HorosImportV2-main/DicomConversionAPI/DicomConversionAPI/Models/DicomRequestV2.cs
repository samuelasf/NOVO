namespace DicomConversionAPI.Models
{
    public class DicomRequestV2
    {
        public string patientId { get; set; }
        public string patientName { get; set; }        
        public string institutionName { get; set; }
        public string dob { get; set; }
        public string accession { get; set; }
        public string modality { get; set; }
        public string generate { get; set; }
        public string filedata { get; set; }
        public string comments { get; set; }




    }
}