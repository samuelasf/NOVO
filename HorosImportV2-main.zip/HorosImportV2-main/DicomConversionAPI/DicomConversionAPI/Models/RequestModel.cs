﻿namespace DicomConversionAPI.Models
{
    public class RequestModelDicomSend
    {        
        public  DicomRequest? dicomRequest { get; set; }
        public List<ResultModel>? dicomFiles { get; set; }
    }

}
