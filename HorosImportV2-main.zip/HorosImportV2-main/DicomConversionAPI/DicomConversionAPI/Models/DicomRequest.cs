namespace DicomConversionAPI.Models
{
    public class DicomRequest
    {
        public string id { get; set; }
        public List<Image> image { get; set; }
        public DateTime? studyDateTime { get; set; }
        public string? comments { get; set; }
        public string? clinicalHistory { get; set; }
        public string? examDescription { get; set; }
        public string? referingPhysician { get; set; }
        public string? performer { get; set; }
        public string? modality { get; set; }
        public string dob { get; set; }
        public string sex { get; set; }
        public string accession { get; set; }
        public string patientName { get; set; }
        public string patientID { get; set; }
        public string institutionName { get; set; }
        public DateTime? createdAt { get; set; }

        public class Image
        {
            public string id { get; set; }
            public string name { get; set; }
            //public int sizeInBytes { get; set; }
            //public string publicUrl { get; set; }
            public string privateUrl { get; set; }
            public string downloadUrl { get; set; }
            public bool @new { get; set; }
        }


    }
}