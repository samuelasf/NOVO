import React from 'react';
import MasterView from './components/master';

function App() {
  return (
    <div className="App">
      <MasterView />
    </div>
  );
}

export default App;
