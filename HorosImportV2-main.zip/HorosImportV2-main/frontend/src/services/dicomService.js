import axios from 'axios';
import { hideWaiting, showWaiting } from '../components/alert';
import { API_DICOM } from '../config';
const Endpoints = {
    API_IMAGEORPDF :  API_DICOM + "/dicomconvert/imageOrPdf",
    API_MWL : API_DICOM +"/dicomconvert/mwl"    
    
}

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms + Math.floor(Math.random() * 500)));
}
async function sleep(fn, ...args) {
    await timeout(5000 + Math.floor(Math.random() * 500));
    return fn(...args);
}

// export default async function dicomSend (data)
// {
//     try 
//     {
//         showWaiting();
        

//         const res =  await axios.post( Endpoints.API_IMAGEORPDF, data);
//         console.log(res)
//         await timeout(2000);
//         hideWaiting();
//         if (!(res.length > 0 && res.some(x=>x.status==='failure')  ))
//         {
//             return true;
//         }
//         return false;

//     }
//     catch(error)
//     {
//         if (error.response) {
//             // Request made but the server responded with an error
//             console.log(error.response.data);
//             console.log(error.response.status);
//             console.log(error.response.headers);
//         } else if (error.request) {
//             // Request made but no response is received from the server.
//             console.log(error.request);
//         } else {
//             // Error occured while setting up the request
//             console.log('Error', error.message);
//         }
//     }

// }

export default async function dicomSend (data)
{
    try 
    {
        showWaiting();
        

        const res =  await axios.post( Endpoints.API_IMAGEORPDF, data);
        console.log(res)
        await timeout(2000);
        hideWaiting();
        if (!(res.length > 0 && res.some(x=>x.status==='failure')  ))
        {
            return {jobStatus: true, errorMessage: null};
        }
        return {jobStatus: false, errorMessage: null};

    }
    catch(error)
    {
        if (error.response) {
            // Request made but the server responded with an error
            console.log(error.response.data);            
            console.log(error.response.status);
            console.log(error.response.headers);
            return {jobStatus: false, errorMessage: error.response.data};
        } else if (error.request) {
            // Request made but no response is received from the server.
            console.log(error.request);
        } else {
            // Error occured while setting up the request
            console.log('Error', error.message);
        }
    }

}

export  async function mwlSend (data)
{
    try 
    {
        showWaiting();
        const res =  await axios.post( Endpoints.API_MWL,{...data, filedata:""});
        hideWaiting();
        if (res)
        {
             return {jobStatus: true, errorMessage:""};
        }
        return {jobStatus: false, errorMessage:""};

    }
    catch(error)
    {
        if (error.response) {
            // Request made but the server responded with an error
            console.log(error.response.data);            
            console.log(error.response.status);
            console.log(error.response.headers);
            return {jobStatus: false, errorMessage: error.response.data};
        } else if (error.request) {
            // Request made but no response is received from the server.
            console.log(error.request);
        } else {
            // Error occured while setting up the request
            console.log('Error', error.message);
        }
    }
}

