export const API_DICOM= "/api"
//export const API_DICOM= "http://localhost:5263/api"