import React, { useState } from "react";
import Landing from "../pages/Landing";
import Success from "../pages/Success";
import ChoosePath from "../pages/ChoosePath";
import PasteText from "../pages/PasteText";
import Results from "../pages/Results";
import UploadFile from "../pages/UploadFile";
import { BrowserRouter as Router, Switch, Route, Routes, Link } from "react-router-dom";
import styles from "./style.module.css";
import ConfigureInstitution from "../pages/Configuration";

export default function MasterView() {
  return (    
      <Router>
        <Link to="/">
          <div className={styles.logoContainer}>
            <img className={styles.logoIcon} src="/resources/logo_exc.svg" /> 
            CRIAR  PACIENTE          
          </div>
        </Link>
        <Routes>
          {/* <Route path="/upload">
            <UploadFile />
          </Route>
          <Route path="/paste">
            <PasteText />
          </Route>
          <Route path="/choose">
            <ChoosePath />
          </Route>
          <Route path="/results">
            <Results />
            
          </Route> */}

          <Route path="/" element={<Landing />} />
          <Route path="/success" element={<Success />} />
          <Route path="/cadastro" element={<ConfigureInstitution />} />
        
        </Routes>
      </Router>    
  );
}
