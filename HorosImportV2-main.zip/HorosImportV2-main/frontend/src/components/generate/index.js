import React from "react";
import axios from "axios";

export default function GenerateButton({ imageFile }) {
  const str = {
    result:
      "- optic agnosia arcuate sulcus broad streams intraparietal sulcus ventral\n\t- diff layers despond\n\t\t- communicable mach score legitamate power expert personal power reward referent coercive good attitude\n\t\t- chapter management intro\n"
  };
  // "- optic agnosia arcuate sulcus broad streams intraparietal sulcus ventral\\n\\t- diff layers despond\\n\\t\\t- communicable mach score legitamate power expert personal power reward referent coercive good attitude\\n\\t\\t- chapter management intro\\n"
  console.log(
    "- optic agnosia arcuate sulcus broad streams intraparietal sulcus ventral\n\t- diff layers despond\n\t\t- communicable mach score legitamate power expert personal power reward referent coercive good attitude\n\t\t- chapter management intro\n"
  );
  const mdData = JSON.stringify(str);
  console.log(mdData);
  const apiUrl = "https://mindmap-api.9aditya9.repl.co/find";
  const handleClick = () => {
    if (imageFile) {
      const formData = new FormData();
      formData.append("image", imageFile);
      const data = axios.post(apiUrl, formData);
      console.log(data);
      // need markdown file here
    }
  };
  return (
    <button className="featureButton" onClick={() => handleClick()}>
      Generate Mind Map
    </button>
  );
}

// Add the file to a formData object, and set the Content-Type header to multipart/form-data.

// var formData = new FormData();
// var imagefile = document.querySelector('#file');
// formData.append("image", imagefile.files[0]);
// axios.post('upload_file', formData, {
//     headers: {
//       'Content-Type': 'multipart/form-data'
//     }
// })
