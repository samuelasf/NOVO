import React, { useEffect } from 'react';
import styles from './style.module.css';
import {
  Link, useNavigate
} from "react-router-dom";
import { Fade } from 'react-reveal';
import { useForm } from "react-hook-form";
import { getInstitutionName, setInstitutionName } from '../../helpers';


export default function ConfigureInstitution() {
  const navigate = useNavigate();

  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue 
  } = useForm({
    mode: "onChange"
  });
 
  
  useEffect(() => {
    setValue("institutionName",getInstitutionName())
  }, [])
  
  const onSubmit = async (data) => {
    
    setInstitutionName(data.institutionName)
    navigate("/")
  }
  const handleSubmitWithoutPropagation = (e) => {
    e.preventDefault();
    e.stopPropagation();
    handleSubmit(onSubmit)(e);
  };
  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <Fade bottom>
          <h1 style={{textAlign:"center"}}> configurar instituição  <br/>padrão</h1> 

          <form  onSubmit={handleSubmitWithoutPropagation}>
     
     <label htmlFor="institutionName">Nome da instituição *  {errors.institutionName && <span style={{color:"red"}}>| {errors.institutionName.message}</span>}</label>
     <input 
       placeholder="Nome da instituição"
       {...register("institutionName")}
     />
      <input className={`featureButton2`} type="submit" value={"Enviar"} />
     </form>

    
        </Fade>
      </div>
    </div >
  )
}

