import React from 'react';
import styles from './style.module.css';
import {
  Link
} from "react-router-dom";
import { Fade } from 'react-reveal';

export default function Landing() {
  const institutionNameURL = window.institutionName?'/?institutionName='+window.institutionName:'/';
  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <Fade bottom>
          <h1 style={{textAlign:"center"}}> Paciente criado com sucesso! </h1>        
          <Link to={institutionNameURL} className={`featureButton2`} >
            <button className={`featureButton2`}>Recomeçar</button>
          </Link>
        </Fade>
      </div>
    </div >
  )
}