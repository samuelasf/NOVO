import React, {useRef,useState} from 'react';
import styles from './style.module.css';
import {
  Link
} from "react-router-dom";
import { Fade } from 'react-reveal';
import { useForm , useWatch} from "react-hook-form";
import { usePrettyPrintedState } from "./usePrettyPrintedState";
import Cube from "../../icon/Cube";
import { FileDrop } from "react-file-drop";
import Upload from "../../icon/Upload";
import GenerateButton from "../../generate";
import dicomService, {mwlSend} from "../../../services/dicomService";
import { useNavigate, useParams , useSearchParams} from "react-router-dom";
import AlertDialog from '../../dialogs/alertDialog';
import { showInfoMessage, showSavedFailure, showWaiting } from '../../alert';
import { getInstitutionName } from '../../helpers';

export default function Landing() {
  
  const navigate = useNavigate();
  //const {institutionName} = useParams();
  const [searchParams, setSearchParams] = useSearchParams();  

  const institutionName =  searchParams.get('institutionName');
  window.institutionName = institutionName ;
  const [submitValue, setSubmitValue] = usePrettyPrintedState();
  const {
    register, getFieldState, getValues, control,
    formState: { errors },
    handleSubmit
  } = useForm({
    mode: "onChange",
    defaultValues: {
      generate: "DICOM"
    }
  });
  const [selectFile, setSelectFile] = useState(null);
  const toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
});
const [dialogOpen, setDialogOpen] = useState(false);

  const onSubmit = async (data) => {
    //console.log(data)
    //data.preventDefault();
    let postdata= {}
    if (selectFile && data.generate !== "MWL")
    {
      let filedata = await toBase64(selectFile);
      postdata = {...data , filedata  , generate : data.generate};
      
      if (cinstitutionName) postdata = {...postdata,  institutionName :data.institutionName ||  cinstitutionName  };
      let dicomServiceRes = await dicomService(postdata);
      //console.log(dicomServiceRes)
       if (!dicomServiceRes.jobStatus)
       {
         if (dicomServiceRes.errorMessage === "error_1") {
          showSavedFailure("Serviço Dicom","Nome da instintuição não encontrado!")          
          return;
         }
          showSavedFailure("Serviço Dicom",dicomServiceRes.errorMessage)          
          return;
       }
       showWaiting("Redirecionando...")       
       window.location.replace('https://exames.center/studyList?searchAccessionNumber='+data.accession);
    }
    else  if (data.generate === "MWL")
    {
      postdata = {...data , generate : data.generate};
      if (cinstitutionName) postdata = {...data, institutionName :data.institutionName ||  cinstitutionName };
      let mwlSendRes = await mwlSend(postdata);

      if (!mwlSendRes.jobStatus) 
       {
          //setDialogOpen(true)
          showSavedFailure("Serviço Dicom",mwlSendRes.errorMessage)
          //showInfoMessage("Dicom Service","Error Connecting")
          return;
       }
       navigate('/success')
    }
    

    return null;
    //navigate(institutionName?'/?institutionName='+institutionName:'/');


    //console.log(JSON.stringify(postdata));
  };


  

  const fileInputRef = useRef(null);
  const generate = useWatch({
    control,
    name: "generate",
  });
  const onFileInputChange = async (event) => {
    event.preventDefault();
    event.stopPropagation();
    const file = event.target.files[0];
    console.log(file.type)
    
    if (!file) {
      return;
    }    
    if (( generate === "DICOM") && (
      file.type === "image/jpeg" ||
      file.type === "image/png" ||
      file.type === "application/pdf" ||
      file.type === "application/x-zip-compressed" ||
      file.type === "image/jpg")
    ) {
      setSelectFile(file);

    } 
    else if (generate === "ANY")
    {
console.log("file")
      setSelectFile(file);
    }
  };


  const onTargetClick = () => {
    fileInputRef.current.click();
  };

  const handleSubmitWithoutPropagation = (e) => {
    e.preventDefault();
    e.stopPropagation();
    handleSubmit(onSubmit)(e);
  };

  const cinstitutionName = institutionName|| getInstitutionName() ;

  const formRef = useRef();
 
  return (
    
    <Fade bottom delay={500}>
     <AlertDialog dialogOpen={dialogOpen} setDialogOpen= {setDialogOpen} message={"Could not send!"}></AlertDialog>
   
     <div className={styles.flexArea}>
      <div className={styles.container}>
      
          <form ref={formRef} onSubmit={handleSubmitWithoutPropagation}>
          <h3 style={{textAlign:"center"}}>{cinstitutionName}</h3>
          <label htmlFor="patientId">ID Paciente *  {errors.patientId && <span style={{color:"red"}}>| {errors.patientId.message}</span>}</label>
          <input 
            placeholder="ID Paciente"
            {...register("patientId", {
              required: " requeridas"
            })}
          />
         

          <label htmlFor="patientName">Nome *  {errors.patientName && <span  style={{color:"red"}}>| {errors.patientName.message}</span>}</label>
          <input
            placeholder="Nome"
            {...register("patientName", {
              required: " requeridas"
            })}
          />
         

          <label htmlFor="dob">Data de Nascimento *  {errors.dob && <span style={{color:"red"}}>| {errors.dob.message}</span>}</label>
          <input
            type="date"
            //placeholder="dd-MM-yyyy"
            pattern="\d{1,2}/\d{1,2}/\d{4}"
            //pattern='(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})'

            {...register("dob", {
              required: " requeridas",
              valueAsDate: true,
              // pattern: {
              //   value: /^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d$/,
              //   message: "Invalid date"
              // }
            })}
          />
          
          {!(institutionName || cinstitutionName.length>0) && (
            <>
              <label htmlFor="institutionName">Nome da instituição *  {errors.institutionName && <span  style={{color:"red"}}>| {errors.institutionName.message}</span>}</label>
              <input
                placeholder="Nome da instituição"
                {...register("institutionName", {
                  required: " requeridas",
                  
                })}
              />
            </>
          )}

          
         

          <label htmlFor="accession">Número de acesso *  {errors.accession && <span  style={{color:"red"}}>| {errors.accession.message}</span>}</label>
          <input
            placeholder="Número de acesso"
            {...register("accession", {
              required: " requeridas"
            })}
          />
         


          <label htmlFor="modality">Modalidade *   {errors.modality && <span  style={{color:"red"}}>| {errors.modality.message}</span>}</label>
          <input
            placeholder="Modalidade"
            {...register("modality", {
              required: " required",
              // pattern: {
              //   value: /^CT|CR|RF|NM|MR|MG|OT|DX$/,
              //   message: "Invalid modality - CT | CR | RF | NM | MR | MG | OT | DX are accepted"
              // }
            })}
          />

          {/* <select {...register("modality",{
              required: " requeridas"
            })}>
            <option value="CT">CT</option>
            <option value="CR">CR</option>
            <option value="DX">DX</option>
            <option value="DX">RF</option>
            <option value="DX">XA</option>
            <option value="DX">NM</option>
            <option value="DX">MG</option>
            <option value="DX">MR</option>
            <option value="DX">OT</option>
          </select> */}

          
          <label htmlFor="comments">Comentários  </label>
          <input {...register("comments",{
              required: false
            })}
            placeholder="Comentários"           
          />

          <label htmlFor="generate">Criar *   {errors.generate && <span  style={{color:"red"}}>| {errors.generate.message}</span>}</label>
          <select {...register("generate",{
              required: " requeridas"
            })}>
            <option value="MWL">Arquivo Worklist</option>
            <option value="DICOM">Arquivo Dicom</option>
            <option value="ANY">Outros Arquivos</option>            
          </select> 


          {/* <label htmlFor="email">Email</label>
          <input
            placeholder="bluebill1049@hotmail.com"
            type="text"
            {...register("email", {
              required: "this is required",
              pattern: {
                value: /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
                message: "Invalid email address"
              }
            })}
          />
          {errors.lastName && <p>{errors.lastName.message}</p>} */}

     

       
          {/* <Link to='/choose'>
            <button className={`featureButton`}>Start</button>
          </Link> */}

          {/* <div className={styles.popup}>
            
            <div className={styles.popupTextbox}>
              <Cube />
              <p className={styles.popupText}>
                Radiology Request - .png, .jpg, .jpeg, .pdf and .zip
              </p>
            </div>
          </div> */}
         
          {generate !== "MWL" && (<div>
          <input
            onChange={onFileInputChange}
            ref={fileInputRef}
            type="file"
            //accept=".png,.jpg,.jpeg,.pdf,.zip"

            accept={generate === "DICOM"? ".png,.jpg,.jpeg,.pdf,.zip" : ""}
            className={styles.hidden}
          />
          <div className={styles.text}>
            <input type="button" onClick={onTargetClick} className={styles.uploadBtn} value={"📂 Imagem"} style={{"width":"8.2em"}} />
              
            <p style={{color:"white"}}>
              {selectFile !== null ? (
                <>
                  {selectFile.name}
                  <span
                    className={styles.x}
                    onClick={() => setSelectFile(null)}
                  >
                    ✕
                  </span>
                </>
              ) : (
                "Escolher arquivo..."
              )}
            </p>
          </div></div>
          )}

          {/* <FileDrop
            onDrop={(files, event) => setSelectFile(files[0])}
            onTargetClick={onTargetClick}
            targetClassName={styles.target}
            className={styles.filedrop}
            draggingOverFrameClassName={styles.filedropDrag}
          >
            <>
              <Upload className={styles.icon} />
              Click or Drag and drop file
            </>
          </FileDrop>          */}
          {/* <div style={{display:"-webkit-inline-box", marginLeft:"9px"}}>
            <label htmlFor="dob">Gerar MWL</label>
            <input {...register("generateMWL", {
    setValueAs: v => String(v),
  }) } type="checkbox"   defaultChecked={false} />
          </div>
           */}

          <input className={`featureButton`} type="submit" value={"Enviar"} />
              
         </form>
       
        </div>
     
       </div> 
 
    </Fade>
  )
}
