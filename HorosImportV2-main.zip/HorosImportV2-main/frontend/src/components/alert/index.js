import SwalOrignal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import loading_spinner from "../../assets/loading_spinner.gif";
const SwalWithContent = withReactContent(SwalOrignal);

function MySwal(props) {
    SwalWithContent.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger",
      },
      buttonsStyling: false,
    });
    SwalWithContent.fire({
      showClass: {
        popup: "animated fadeIn faster",
      },
      hideClass: {
        popup: "animated fadeOut faster",
      },
      ...props,
    }).then((result) => {
      if (props.onResult) props.onResult(result);
    });
  }

export function showWaiting(title, onClose) {
    SwalWithContent.close();
    MySwal({
      title: title ? title : "por favor, aguarde...",
      imageUrl: loading_spinner,
      imageWidth: "150px",
      showConfirmButton: false,
      //onClose: onClose
    });
  }
  export function hideWaiting() {
    SwalWithContent.close();
    //if (onClose) onClose();
  }
  
  export function showInfoMessage(title, titleText, message) {
    SwalWithContent.close();
    MySwal({
      icon: "info",
      title: title,
      titleText: titleText,
      text: message,
      allowEscapeKey: true,
      allowEnterKey: true,
    });
  }

  
export function showSavedFailure(manager, text) {
  SwalWithContent.close();
  MySwal({
    icon: "error",
    title: manager + "",
    showConfirmButton: true,
    text: text ? text : null,
  });
}