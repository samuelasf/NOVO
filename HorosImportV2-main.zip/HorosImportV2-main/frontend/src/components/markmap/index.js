import React, { useEffect } from "react";
import { Transformer } from "markmap-lib";

export default function MarkmapView() {
  useEffect(() => {
    const transformer = new Transformer();

    // 1. transform markdown
    const { root, features } = transformer.transform(markdown);
    const { styles, scripts } = transformer.getAssets(features);
  });
  return <svg id="markmap" style={{ width: "800px", height: "800px" }}></svg>;
}
