import { Cookies } from "react-cookie";

  
  export const getInstitutionName = () => {
    const cookies = new Cookies();
    const institutionName = cookies.get("institutionName");
    //console.log(building);
    return institutionName ? (typeof building == "string" ? institutionName : institutionName) : "";
  }
  export const setInstitutionName = (institutionName) => {
    const expires = new Date();
    expires.setDate(Date.now() + 1000 * 60 * 60 * 24 * 365*10);
    let maxAge = 60 * 60 * 24 * 365;
    let cookies = new Cookies();    
    cookies.set("institutionName", institutionName, { path: "/", expires, maxAge });
  }

  
  