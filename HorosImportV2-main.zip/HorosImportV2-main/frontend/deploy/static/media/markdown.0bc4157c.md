# markmap

## Links

- <https://markmap.js.org/>
- [GitHub](https://github.com/gera2ld/markmap)

## Related

- [coc-markmap](https://github.com/gera2ld/coc-markmap)
- [gatsby-remark-markmap](https://github.com/gera2ld/gatsby-remark-markmap)

## Features

- links
- **inline** ~~text~~ _styles_
- multiline
  text
- `inline code`
- ```js
  console.log("code block");
  ```
- Katex - $x = {-b \pm \sqrt{b^2-4ac} \over 2a}$
